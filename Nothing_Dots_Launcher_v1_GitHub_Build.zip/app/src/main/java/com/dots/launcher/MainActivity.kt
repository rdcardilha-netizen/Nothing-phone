package com.dots.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private lateinit var searchBox: EditText
    private var apps: List<ResolveInfo> = emptyList()
    private var query = ""

    private val bg get() = if (Prefs.dark(this)) Color.rgb(18, 18, 18) else Color.rgb(244, 244, 241)
    private val fg get() = if (Prefs.dark(this)) Color.WHITE else Color.rgb(25, 25, 25)
    private val muted get() = if (Prefs.dark(this)) 0xFFAAAAAA.toInt() else 0xFF666666.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            window.setBackgroundDrawable(WallpaperManager.getInstance(this).drawable)
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
        } catch (_: Exception) {
            window.decorView.setBackgroundColor(bg)
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        loadApps()
        buildScreen()
    }

    override fun onResume() {
        super.onResume()
        if (::root.isInitialized) buildScreen()
    }

    private fun loadApps() {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(12))
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "NOTHING  •  DOTS"
            textSize = 12f
            letterSpacing = 0.16f
            setTextColor(fg)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        top.addView(brand, LinearLayout.LayoutParams(0, dp(40), 1f))
        val settings = TextView(this).apply {
            text = "•••"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(fg)
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        top.addView(settings, LinearLayout.LayoutParams(dp(48), dp(40)))
        root.addView(top)

        if (Prefs.clock(this)) {
            val clock = TextView(this).apply {
                text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                textSize = 58f
                letterSpacing = -0.05f
                typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                setTextColor(fg)
                setPadding(0, dp(24), 0, 0)
            }
            root.addView(clock)
            val date = TextView(this).apply {
                text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
                textSize = 13f
                setTextColor(muted)
                setPadding(0, 0, 0, dp(20))
            }
            root.addView(date)
        } else {
            root.addView(View(this), LinearLayout.LayoutParams(1, dp(22)))
        }

        if (Prefs.search(this)) {
            searchBox = EditText(this).apply {
                hint = "Search apps"
                textSize = 14f
                singleLine = true
                setTextColor(fg)
                setHintTextColor(muted)
                setPadding(dp(16), 0, dp(16), 0)
                background = rounded(if (Prefs.dark(this@MainActivity)) 0xFF292929.toInt() else Color.WHITE, 24)
                addTextChangedListener(SimpleWatcher { value ->
                    query = value
                    renderApps()
                })
            }
            root.addView(searchBox, LinearLayout.LayoutParams(-1, dp(48)).apply {
                bottomMargin = dp(16)
            })
        }

        val section = TextView(this).apply {
            text = "APPS"
            textSize = 11f
            letterSpacing = 0.18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            setPadding(0, dp(4), 0, dp(12))
        }
        root.addView(section)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        appGrid = GridLayout(this).apply {
            columnCount = Prefs.columns(this@MainActivity)
            useDefaultMargins = false
        }
        scroll.addView(appGrid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "●   ●   ●   ●"
            textSize = 12f
            letterSpacing = 0.25f
            gravity = Gravity.CENTER
            setTextColor(if (Prefs.dark(this@MainActivity)) 0xFFCCCCCC.toInt() else 0xFF444444.toInt())
            setPadding(0, dp(12), 0, dp(8))
        }
        root.addView(footer)
        setContentView(root)
        renderApps()
    }

    private fun renderApps() {
        if (!::appGrid.isInitialized) return
        appGrid.removeAllViews()
        val filtered = apps.filter {
            it.loadLabel(packageManager).toString().contains(query, ignoreCase = true)
        }
        val columns = Prefs.columns(this)
        appGrid.columnCount = columns
        val cellWidth = (resources.displayMetrics.widthPixels - dp(44)) / columns
        filtered.forEach { info ->
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(8), dp(3), dp(12))
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            cell.addView(icon, LinearLayout.LayoutParams(dp(Prefs.iconSize(this)), dp(Prefs.iconSize(this))))
            if (Prefs.labels(this)) {
                val label = TextView(this).apply {
                    text = info.loadLabel(packageManager)
                    textSize = 10.5f
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(fg)
                    setPadding(0, dp(6), 0, 0)
                }
                cell.addView(label, LinearLayout.LayoutParams(-1, -2))
            }
            appGrid.addView(cell, GridLayout.LayoutParams().apply {
                width = cellWidth
                height = dp(94)
                setGravity(Gravity.CENTER)
            })
        }
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
