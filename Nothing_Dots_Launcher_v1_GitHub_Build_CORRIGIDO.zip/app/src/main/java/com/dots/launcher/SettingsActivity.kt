package com.dots.launcher

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {
    private val dark get() = Prefs.dark(this)
    private val fg get() = if (dark) Color.WHITE else Color.rgb(25, 25, 25)
    private val bg get() = if (dark) Color.rgb(18, 18, 18) else Color.rgb(244, 244, 241)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(30), dp(24), dp(24))
            setBackgroundColor(bg)
        }
        page.addView(TextView(this).apply {
            text = "DOTS SETTINGS"
            textSize = 13f
            letterSpacing = 0.16f
            setTextColor(fg)
        })
        page.addView(TextView(this).apply {
            text = "Make it yours."
            textSize = 30f
            setTextColor(fg)
            setPadding(0, dp(10), 0, dp(26))
        })

        addSwitch(page, "Dark appearance", "dark", Prefs.dark(this))
        addSwitch(page, "Show clock and date", "clock", Prefs.clock(this))
        addSwitch(page, "Show app search", "search", Prefs.search(this))
        addSwitch(page, "Show app names", "labels", Prefs.labels(this))

        addSlider(page, "Home screen columns", 3, 6, Prefs.columns(this), "columns")
        addSlider(page, "Icon size", 40, 68, Prefs.iconSize(this), "icon_size")

        page.addView(TextView(this).apply {
            text = "Changes apply when you return to the home screen."
            textSize = 12f
            setTextColor(if (dark) 0xFFAAAAAA.toInt() else 0xFF666666.toInt())
            setPadding(0, dp(24), 0, 0)
        })
        setContentView(page)
    }

    private fun addSwitch(parent: LinearLayout, title: String, key: String, checked: Boolean) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(9))
        }
        row.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(fg)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, value -> Prefs.save(this@SettingsActivity, key, value) }
        })
        parent.addView(row)
    }

    private fun addSlider(parent: LinearLayout, title: String, min: Int, max: Int, value: Int, key: String) {
        val label = TextView(this).apply {
            text = "$title: $value"
            textSize = 14f
            setTextColor(fg)
            setPadding(0, dp(16), 0, dp(4))
        }
        parent.addView(label)
        parent.addView(SeekBar(this).apply {
            this.max = max - min
            progress = value - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = min + progress
                    label.text = "$title: $v"
                    Prefs.save(this@SettingsActivity, key, v)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        })
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
