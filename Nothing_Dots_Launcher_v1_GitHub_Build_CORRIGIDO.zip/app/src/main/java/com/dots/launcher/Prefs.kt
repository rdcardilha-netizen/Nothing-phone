package com.dots.launcher

import android.content.Context

object Prefs {
    private const val FILE = "dots_preferences"
    private fun p(context: Context) = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun columns(context: Context) = p(context).getInt("columns", 4).coerceIn(3, 6)
    fun iconSize(context: Context) = p(context).getInt("icon_size", 52).coerceIn(40, 68)
    fun labels(context: Context) = p(context).getBoolean("labels", true)
    fun dark(context: Context) = p(context).getBoolean("dark", false)
    fun clock(context: Context) = p(context).getBoolean("clock", true)
    fun search(context: Context) = p(context).getBoolean("search", true)

    fun save(context: Context, key: String, value: Any) {
        val editor = p(context).edit()
        when (value) {
            is Int -> editor.putInt(key, value)
            is Boolean -> editor.putBoolean(key, value)
            is String -> editor.putString(key, value)
        }
        editor.apply()
    }
}
