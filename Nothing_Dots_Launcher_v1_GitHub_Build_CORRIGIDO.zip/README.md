# Nothing Dots Launcher

A lightweight Android home launcher with a clean monochrome, dot-inspired visual language.

## Included
- Native Kotlin / Android UI; no third-party runtime libraries
- App drawer with app search
- Minimal clock and date
- 3–6 column grid
- Adjustable icon size
- Optional app labels, clock, search, and dark appearance
- Settings stored locally
- Android 8.0 (API 26) and newer

## Build
Use JDK 17 and Gradle 8.5:
`gradle :app:assembleRelease --no-daemon`

APK output:
`app/build/outputs/apk/release/app-release.apk`

This project is a launcher application, not a custom Android ROM. The visual style is inspired by minimalist dot-based interfaces and is not affiliated with Nothing Technology Limited.
